
     java -jar -Xmx256m Movie2DNGGUI-dist.jar
     